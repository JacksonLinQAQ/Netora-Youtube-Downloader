from Netora.YTDownloader.YTDownloader import YTDownloader

yt = YTDownloader('https://www.youtube.com/watch?v=k6jqx9kZgPM')

yt.options.select_by_expression('-a webm -v 2160/webm -of mp4')

print(yt.options.output_format)

yt.download()